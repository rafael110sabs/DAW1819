var express = require('express');
var router = express.Router();
var axios = require('axios');

/* GET home page. */
router.get('/:classe', function(req, res) {
  axios.get('http://clav-test.di.uminho.pt/api/classes/c'+req.params.classe)
        .then(resposta=> {
            if(resposta.data){
                axios.get('http://clav-test.di.uminho.pt/api/classes/c'+req.params.classe+'/descendencia')
                    .then(descendencia=> res.render('classe-page', { title: '('+ resposta.data[0].codigo +') '+resposta.data[0].titulo, c: resposta.data[0], desc:descendencia.data }))
                    .catch(erro=>{
                        res.render('error', { error: erro, message:'Erro ao carregar da API.'});
                    })
          }
        })
      .catch(erro=>{
          res.render('error', { error: erro, message:'Erro ao carregar da API.'});
      })
});

module.exports = router;
