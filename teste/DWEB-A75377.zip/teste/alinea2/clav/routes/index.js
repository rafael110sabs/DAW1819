var express = require('express');
var router = express.Router();
var axios = require('axios');

/* GET home page. */
router.get('/', function(req, res) {
  axios.get('http://clav-test.di.uminho.pt/api/classes/nivel/1')
      .then(resposta=> res.render('index', {title:"CLAV", classes: resposta.data }))
      .catch(erro=>{
          res.render('error', { error: erro, message:'Erro ao carregar a BD.'});
      })
});

module.exports = router;
