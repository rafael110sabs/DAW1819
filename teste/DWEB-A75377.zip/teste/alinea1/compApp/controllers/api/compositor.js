var Compositor = require('../../models/Compositor')

// Lista de compositores
module.exports.listar = () =>{
    return Compositor
        .find({},{_id:true,nome:true,dataNasc:true})
        .exec()
}
//Devolve a informação de um Compositor
module.exports.consultar = (eid) =>{
    return Compositor
    .findOne({_id:eid})
    .exec()
}

module.exports.inserir = compositor =>{
    return Compositor.create(compositor)
}

// Lista os compositores do tipo T
module.exports.listarPeriodo= periodo =>{
    return Compositor
        .find({periodo:periodo})
        .exec()
}
// Lista os compositores da data D
module.exports.listarDataPeriodo= (data,periodo) =>{
    return Compositor
        .find({dataNasc: {$gt: data},periodo:periodo})
        .exec()
}

// Inserir os compositores
// module.exports.inserir = Compositor => {
//     var novo = new Compositor(Compositor)
//     return new Promise(function (fulfill, reject){
//         novo.save(erro => {
//             if(erro ) reject({...})
//             else fulfill({...})
//         }
//     })
// }
