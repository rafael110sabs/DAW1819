var express = require('express')
var router = express.Router();
var Compositor = require('../../controllers/api/compositor')

// Api para os compositores

router.get('/', (req,res)=>{
    if(req.query.data && req.query.periodo){
        Compositor.listarDataPeriodo(req.query.data, req.query.periodo)
        .then(dados => res.jsonp(dados))
        .catch(erro => res.status(500).send('Erro na listagem por data e periodo.'))
    }
    else if(req.query.periodo){
        Compositor.listarPeriodo(req.query.periodo)
        .then(dados => res.jsonp(dados))
        .catch(erro => res.status(500).send('Erro na listagem por periodo.'))
    } else {
        Compositor.listar()
        .then(dados => res.jsonp(dados))
        .catch(erro => res.status(500).send('Erro na listagem de compositores.'))
    }
})

router.get('/:id', (req,res)=>{
    Compositor.consultar(req.params.id)
    .then(dados => res.jsonp(dados))
    .catch(erro => res.status(500).send('Erro na consulta do compositor '+req.params.eid))
})

module.exports = router;